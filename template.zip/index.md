---
---

<br id="idx00">
Ever did something and forgot how some years later?
Or months later? Or even weeks later? 
Therefore, keep a memo about it!
I am {{ site.author }}, {{ site.address }} and this is the Way!

<br id="idx01">
## Recent Links
* [TOC: Table of Contents](0/001.md)

<br id="idx02">
